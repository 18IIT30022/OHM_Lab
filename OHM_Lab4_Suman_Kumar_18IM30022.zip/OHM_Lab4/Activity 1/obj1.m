
function z=obj1(x)
    z= x.^2 + x.^3 - 2*x;
end